// 1 d

public class General extends Compartment {

	@Override
	public String notice() {
		// TODO Auto-generated method stub
		return new String("General");
	}

}
