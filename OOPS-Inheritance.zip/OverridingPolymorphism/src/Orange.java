// 1 c

public class Orange extends Fruit {

	@Override
	public void eat() {
		System.out.println("The orange tastes sweet and sour");
	}

}
