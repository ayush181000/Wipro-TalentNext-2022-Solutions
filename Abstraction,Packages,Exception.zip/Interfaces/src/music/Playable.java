// 1 a

package music;

public interface Playable {

	void play();
	
}
