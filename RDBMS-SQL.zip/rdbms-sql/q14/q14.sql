select last_name, hire_date from employees 
where hire_date like '%94';