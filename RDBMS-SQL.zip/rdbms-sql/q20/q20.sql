select last_name from employees 
where last_name like '%a%e%';