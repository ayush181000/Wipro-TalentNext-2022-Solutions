/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.wipro_trainings.rdbms;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class rdbms_sql_q1 {
	public static void main(String[] args) throws SQLException
	{
		DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
		Connection conn =DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","sarthak05");
		Statement stmt =conn.createStatement();
		ResultSet rs=stmt.executeQuery("select * from emp");
		
		while(rs.next())
		{
			System.out.print(rs.getInt(1)+" "+rs.getString(2));
		}
		conn.close();
	}
}