select last_name, department_id from employees 
where employee_id = 176;